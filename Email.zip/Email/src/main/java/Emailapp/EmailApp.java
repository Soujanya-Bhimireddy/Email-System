package Emailapp;

public class EmailApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Email em1=new Email("john","smith");
	System.out.println(em1.showinfo());
	}

}
